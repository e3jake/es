curl -H "content-type: application/json" -XPOST 'https://jsonplaceholder.typicode.com/posts' -d '{
      title: 'foo',
      body: 'bar',
      userId: 1
}'