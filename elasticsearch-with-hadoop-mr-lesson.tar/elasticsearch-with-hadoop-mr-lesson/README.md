# Elasticsearch with Hadoop MR
This is the source code for a lesson on using Elasticsearch with Hadoop MR.

## Build jar with
```
mvn clean package
```
